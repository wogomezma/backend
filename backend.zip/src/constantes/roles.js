const ROLES = ['public', 'user', 'admin', 'premium']

module.exports = ROLES;