const productsData = [
    {
      name: "ProductManager1",
      description: "Terzo",
      price: 10,
      code: "1000",
      carts: [],
      stock: 10,
      thumbnail: "sin imagen",
    },
  ];
  
  module.exports = productsData;